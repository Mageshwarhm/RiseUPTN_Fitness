package com.example.project_riseup;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class privacy extends AppCompatActivity {
    Button approve;
    long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_privacy);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById (R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        approve=findViewById(R.id.approve);
        approve.setOnClickListener(view -> {
            Intent intent=new Intent(privacy.this,Profile.class);
            intent.putExtra("USER_ID", userId);  // Pass the user ID to Profile activity
            startActivity(intent);
        });

    }
}
//package com.example.project_riseup;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.widget.Button;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//public class privacy extends AppCompatActivity {
//    Button approve;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_privacy);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById (R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//        approve=findViewById(R.id.approve);
//        approve.setOnClickListener(view -> {
//            Intent intent=new Intent(privacy.this,Profile.class);
//            startActivity(intent);
//        });
//
//    }
//}