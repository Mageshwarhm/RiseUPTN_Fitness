//package com.example.project_riseup;
//
//public interface onViewUpdateListener {
//    void onViewUpdate(float result);
//}

package com.example.project_riseup;

public interface onViewUpdateListener {
    void onViewUpdate(float result);
}