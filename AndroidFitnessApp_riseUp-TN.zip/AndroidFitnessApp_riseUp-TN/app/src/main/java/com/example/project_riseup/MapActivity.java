package com.example.project_riseup;

//
//
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.SearchView;

//public class MapActivity extends AppCompatActivity {
//
//    private String location;
////    private UserApi userApi;
//    private long userId;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_map);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//
//        Intent intent = getIntent();
//        userId = intent.getLongExtra("USER_ID", -1);
//        if (userId != -1) {
//            // Initialize Retrofit and UserApi
//            userApi = ApiClient.getClient().create(UserApi.class);
//            getUserById(userId);
//        } else {
//            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
//        }
////
////        if (userId != -1) {
////            User user = UserDatabase.getInstance(this).userDao().getUserById(userId);
////            if(!user.getSeeTheInstructions())
////            {
////                Intent intentt =new Intent(MapActivity.this, GroupExpActivity.class);
////                intent.putExtra("USER_ID", userId);
////                startActivity(intentt);
////            }
////        }
//
//
//
//        location = "";
//        // Initialize SearchView
//        SearchView searchView = findViewById(R.id.searchView);
//        searchView.setQueryHint("Find group by ID");
//
//
//        // Set up SearchView listeners
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                // Check if the input is a valid number
//                if (query.matches("\\d+")) {
//                    // Start the ViewGroupById activity and pass the group ID
//                    Intent intent = new Intent(MapActivity.this, ViewGroupsActivity.class);
//                    intent.putExtra("GROUP_ID", Integer.parseInt(query));
//                    startActivity(intent);
//                    return true; // Indicate that the query has been handled
//                } else {
//                    // Show an error message if the input is not a valid ID
//                    Toast.makeText(MapActivity.this, "Please enter a valid group ID", Toast.LENGTH_SHORT).show();
//                    return false; // Indicate that the query was not handled
//                }
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                // Optional: Handle the text change if needed, or just return false
//                return false;
//            }
//        });
//
//
//        // Find ImageViews by ID
//
//        ImageView tabarias = findViewById(R.id.tabarias);
//        ImageView karmiel = findViewById(R.id.karmiel);
//        ImageView tamra = findViewById(R.id.tamra);
//        ImageView nazareth = findViewById(R.id.nazareth);
//        ImageView afula = findViewById(R.id.afula);
//        ImageView karmil = findViewById(R.id.karmil);
//        ImageView nahsholim = findViewById(R.id.nahsholim);
//        ImageView hadera = findViewById(R.id.hadera);
//        ImageView natanya = findViewById(R.id.natanya);
//        ImageView ramatGan = findViewById(R.id.ramatGan);
//        ImageView telAviv = findViewById(R.id.telAviv);
//        ImageView ramla = findViewById(R.id.ramla);
//        ImageView ashdod = findViewById(R.id.ashdod);
//        ImageView ashqelon = findViewById(R.id.ashqelon);
//        ImageView jerusalem = findViewById(R.id.jerusalem);
//        ImageView betShemesh = findViewById(R.id.betShemesh);
//        ImageView beersheba = findViewById(R.id.beersheba);
//        ImageView yeroham = findViewById(R.id.yeroham);
//        ImageView zin = findViewById(R.id.zin);
//        ImageView yahoda = findViewById(R.id.yahoda);
//        ImageView eilat = findViewById(R.id.eilat);
//        ImageView reshonLezion = findViewById(R.id.reshonLezion);
//        ImageView naharia = findViewById(R.id.naharia);
//        ImageView akko = findViewById(R.id.akko);
//        ImageView haifa = findViewById(R.id.haifa);
//        ImageView qiryatShmona = findViewById(R.id.qiryatShmona);
//        ImageView masadah = findViewById(R.id.masadah);
//
//
//
//        setupImageViewClickListener(tabarias, "tabarias");
//        setupImageViewClickListener(karmiel, "karmiel");
//        setupImageViewClickListener(tamra, "tamra");
//        setupImageViewClickListener(nazareth, "nazareth");
//        setupImageViewClickListener(afula, "afula");
//        setupImageViewClickListener(karmil, "karmil");
//        setupImageViewClickListener(nahsholim, "nahsholim");
//        setupImageViewClickListener(hadera, "hadera");
//        setupImageViewClickListener(natanya, "natanya");
//        setupImageViewClickListener(ramatGan, "ramatGan");
//        setupImageViewClickListener(telAviv, "telAviv");
//        setupImageViewClickListener(ramla, "ramla");
//        setupImageViewClickListener(ashdod, "ashdod");
//        setupImageViewClickListener(ashqelon, "ashqelon");
//        setupImageViewClickListener(jerusalem, "jerusalem");
//        setupImageViewClickListener(betShemesh, "betShemesh");
//        setupImageViewClickListener(beersheba, "beersheba");
//        setupImageViewClickListener(yeroham, "yeroham");
//        setupImageViewClickListener(zin, "zin");
//        setupImageViewClickListener(yahoda, "yahoda");
//        setupImageViewClickListener(eilat, "eilat");
//        setupImageViewClickListener(reshonLezion, "reshonLezion");
//        setupImageViewClickListener(naharia, "naharia");
//        setupImageViewClickListener(akko, "akko");
//        setupImageViewClickListener(haifa, "haifa");
//        setupImageViewClickListener(qiryatShmona, "qiryatShmona");
//        setupImageViewClickListener(masadah, "masadah");
//    }
//
//    private void setupImageViewClickListener(ImageView imageView, String locationName) {
//        imageView.setOnClickListener(v -> {
//            Intent intent = new Intent(MapActivity.this, ViewGroupsActivity.class);
//            intent.putExtra("LOCATION", locationName);
//            intent.putExtra("USER_ID", userId);
//            startActivity(intent);
//        });
//    }
//
//
//    private void getUserById(long userId) {
//        Call<User> call = userApi.getUserById(userId);
//        call.enqueue(new Callback<User>() {
//            @Override
//            public void onResponse(Call<User> call, Response<User> response) {
//                if (response.isSuccessful()) {
//                    User user = response.body();
//                    // Handle the user object, e.g., display user details in the UI
//                    if (user != null) {
//                        // Check if the user has seen the instructions
//                        if (!user.getSeeTheInstructions()) {
//                            // Redirect to GroupExpActivity if getSeeTheInstructions is false
//                            Intent intent = new Intent(MapActivity.this, GroupExpActivity.class);
//                            intent.putExtra("USER_ID", userId);
//                            startActivity(intent);
//                            finish();  // Optionally finish the current activity so the user can't navigate back
//                        } else {
//                            Toast.makeText(MapActivity.this, "User: " + user.getFirstName(), Toast.LENGTH_SHORT).show();
//                            // Proceed with the rest of your logic if needed
//                        }
//                    }
//                } else {
//                    Toast.makeText(MapActivity.this, "Failed to retrieve user", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<User> call, Throwable t) {
//                Toast.makeText(MapActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//}
//package com.example.project_riseup;


public class MapActivity extends AppCompatActivity {

    private String location;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_map);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        userId = intent.getLongExtra("USER_ID", -1);
//        int userId = intent.getIntExtra("USER_ID", -1);
//
//        if (userId != -1) {
//            new Thread(() -> {
//                try {
//                    User user = UserDatabase.getInstance(this).userDao().getUserById(userId);
//                    if (!user.getSeeTheInstructions()) {
//                        Intent intentt = new Intent(MapActivity.this, GroupExpActivity.class);
//                        intentt.putExtra("USER_ID", userId);
//                        startActivity(intentt);
//                    });
//                } catch (Exception e) {
//                    runOnUiThread(() -> {
//                        Toast.makeText(MapActivity.this, "Error saving user locally", Toast.LENGTH_SHORT).show();
//                    });
//                }
//            }).start();
        if (userId != -1) {
            new Thread(() -> {
                try {
                    User user = UserDatabase.getInstance(this).userDao().getUserById(userId);
                    runOnUiThread(() -> { // Ensure UI operations are done on the main thread
                        if (user != null && !user.getSeeTheInstructions()) {
                            Intent intentt = new Intent(MapActivity.this, GroupExpActivity.class);
                            intentt.putExtra("USER_ID", userId);
                            startActivity(intentt);
//                            finish(); // Optional: Finish current activity if you don't want it in the back stack
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        Toast.makeText(MapActivity.this, "Error retrieving user from database", Toast.LENGTH_SHORT).show();
                    });
                }
            }).start();
        }




        location = "";
        // Initialize SearchView
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setQueryHint("Find group by ID");


        // Set up SearchView listeners
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                // Check if the input is a valid number
                if (query.matches("\\d+")) {
                    // Start the ViewGroupById activity and pass the group ID
                    Intent intent = new Intent(MapActivity.this, ViewGroupsActivity.class);
                    intent.putExtra("GROUP_ID", Integer.parseInt(query));
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                    return true; // Indicate that the query has been handled
                } else {
                    // Show an error message if the input is not a valid ID
                    Toast.makeText(MapActivity.this, "Please enter a valid group ID", Toast.LENGTH_SHORT).show();
                    return false; // Indicate that the query was not handled
                }
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Optional: Handle the text change if needed, or just return false
                return false;
            }
        });


        // Find ImageViews by ID

        ImageView Tiruvallur = findViewById(R.id.Tiruvallur);
        ImageView Chennai = findViewById(R.id.Chennai);
        ImageView Ranipet = findViewById(R.id.Ranipet);
        ImageView Kancheepuram = findViewById(R.id.Kancheepuram);
        ImageView Chengalpattu = findViewById(R.id.Chengalpattu);
        ImageView Vellore = findViewById(R.id.Vellore);
        ImageView Tiruvannamalai = findViewById(R.id.Tiruvannamalai);
        ImageView Tirupathur = findViewById(R.id.Tirupathur);
        ImageView Krishnagiri = findViewById(R.id.Krishnagiri);
        ImageView Dharmapuri = findViewById(R.id.Dharmapuri);
        ImageView Vilupuram = findViewById(R.id.Vilupuram);
        ImageView Salem = findViewById(R.id.Salem);
        ImageView Kallakurichi = findViewById(R.id.Kallakurichi);
        ImageView Cuddalore = findViewById(R.id.Cuddalore);
        ImageView Erode = findViewById(R.id.Erode);
        ImageView Nilgiris = findViewById(R.id.Nilgiris);
        ImageView Coimbatore = findViewById(R.id.Coimbatore);
        ImageView Tiruppur = findViewById(R.id.Tiruppur);
        ImageView Namakkal = findViewById(R.id.Namakkal);
        ImageView Perambalur = findViewById(R.id.Perambalur);
        ImageView Ariyalur = findViewById(R.id.Ariyalur);
        ImageView Tiruchirappalli = findViewById(R.id.Tiruchirappalli);
        ImageView Karur = findViewById(R.id.Karur);
        ImageView Mayiladuthurai = findViewById(R.id.Mayiladuthurai);
        ImageView Nagapattinam = findViewById(R.id.Nagapattinam);
        ImageView Thiruvarur = findViewById(R.id.Thiruvarur);
        ImageView Thanjavur = findViewById(R.id.Thanjavur);
        ImageView Pudukottai = findViewById(R.id.Pudukottai);
        ImageView Dindigul = findViewById(R.id.Dindigul);
        ImageView Theni = findViewById(R.id.Theni);
        ImageView Madurai = findViewById(R.id.Madurai);
        ImageView Sivaganga = findViewById(R.id.Sivaganga);
        ImageView Virudhunagar = findViewById(R.id.Virudhunagar);
        ImageView Ramanathapuram = findViewById(R.id.Ramanathapuram);
        ImageView Tenkasi = findViewById(R.id.Tenkasi);
        ImageView Thoothukudi = findViewById(R.id.Thoothukudi);
        ImageView Tirunelveli = findViewById(R.id.Tirunelveli);
        ImageView Kanyakumari = findViewById(R.id.Kanyakumari);


        setupImageViewClickListener(Tiruvallur, "Tiruvallur");
        setupImageViewClickListener(Chennai, "Chennai");
        setupImageViewClickListener(Ranipet, "Ranipet");
        setupImageViewClickListener(Kancheepuram, "Kancheepuram");
        setupImageViewClickListener(Chengalpattu, "Chengalpattu");
        setupImageViewClickListener(Vellore, "Vellore");
        setupImageViewClickListener(Tiruvannamalai, "Tiruvannamalai");
        setupImageViewClickListener(Tirupathur, "Tirupathur");
        setupImageViewClickListener(Krishnagiri, "Krishnagiri");
        setupImageViewClickListener(Dharmapuri, "Dharmapuri");
        setupImageViewClickListener(Vilupuram, "Vilupuram");
        setupImageViewClickListener(Salem, "Salem");
        setupImageViewClickListener(Kallakurichi, "Kallakurichi");
        setupImageViewClickListener(Cuddalore, "Cuddalore");
        setupImageViewClickListener(Erode, "Erode");
        setupImageViewClickListener(Nilgiris, "Nilgiris");
        setupImageViewClickListener(Coimbatore, "Coimbatore");
        setupImageViewClickListener(Tiruppur, "Tiruppur");
        setupImageViewClickListener(Namakkal, "Namakkal");
        setupImageViewClickListener(Perambalur, "Perambalur");
        setupImageViewClickListener(Ariyalur, "Ariyalur");
        setupImageViewClickListener(Tiruchirappalli, "Tiruchirappalli");
        setupImageViewClickListener(Karur, "Karur");
        setupImageViewClickListener(Mayiladuthurai, "Mayiladuthurai");
        setupImageViewClickListener(Nagapattinam, "Nagapattinam");
        setupImageViewClickListener(Thiruvarur, "Thiruvarur");
        setupImageViewClickListener(Thanjavur, "Thanjavur");
        setupImageViewClickListener(Pudukottai, "Pudukottai");
        setupImageViewClickListener(Dindigul, "Dindigul");
        setupImageViewClickListener(Theni, "Theni");
        setupImageViewClickListener(Madurai, "Madurai");
        setupImageViewClickListener(Sivaganga, "Sivaganga");
        setupImageViewClickListener(Virudhunagar, "Virudhunagar");
        setupImageViewClickListener(Ramanathapuram, "Ramanathapuram");
        setupImageViewClickListener(Tenkasi, "Tenkasi");
        setupImageViewClickListener(Thoothukudi, "Thoothukudi");
        setupImageViewClickListener(Tirunelveli, "Tirunelveli");
        setupImageViewClickListener(Kanyakumari, "Kanyakumari");

    }

    private void setupImageViewClickListener(ImageView imageView, String locationName) {
        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(MapActivity.this, ViewGroupsActivity.class);
            intent.putExtra("LOCATION", locationName);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }
}