//package com.example.project_riseup;
//
//public interface OnJoinClickListener {
//    void onJoinClick(int position);
//}
package com.example.project_riseup;

public interface OnJoinClickListener {
    void onJoinClick(int position);
}